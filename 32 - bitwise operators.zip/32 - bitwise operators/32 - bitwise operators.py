grade = int(input("Enter your grade: "))

if grade <= 20 and grade >= 17:
    print("تبریک!!! معدل برتر کلاس شدی")
elif grade < 17 and grade >= 15:
    print("معدل بدی نیست ولی میتونه بهتر باشه")
elif grade < 15 and grade >= 10:
    print("اصلا!!! معدل قابل تعریفی نداری! یکم بیشن درسو بخون")
elif grade < 10 and grade >= 0:
    print("اینم نمرس!!! حرفی ندارم")
else:
    print("Invalid grade")

print(grade)
