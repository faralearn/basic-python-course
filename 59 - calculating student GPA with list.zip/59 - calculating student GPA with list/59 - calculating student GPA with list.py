# Initialize an empty list
list = []

# Get student name and append it to the list
name = input("Enter your name: ")
list.append(name)

# Get grades and append them to the list
programmingGrade = int(input("Enter your programming grade: "))
list.append(programmingGrade)

mathGrade = int(input("Enter your math grade: "))
list.append(mathGrade)

englishGrade = int(input("Enter your english grade: "))
list.append(englishGrade)

# Calculate weighted average
ave = ((list[1] * 3) + (list[2] * 2) + (list[3] * 1)) / 6

# Print list and average
print(list)
print("Average is:", ave)
