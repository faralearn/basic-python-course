text = input("Enter your string: ")

# Count sentences based on periods, exclamation marks, and question marks
sentence = text.count(".") + text.count("!") + text.count("?")
print("Sentence is:", sentence)

# Count words by counting spaces
word = text.count(" ") + 1  # Adding 1 to include the last word
print("Word is:", word)

# Count characters
char = len(text)
print("Char is:", char)
