shoa = int(input("Enter shoa: "))

mohit = shoa * 2 * 3.14
masahat = shoa * shoa * 3.14

print("Circumference (mohit) is:", mohit)
print("Area (masahat) is:", masahat)
