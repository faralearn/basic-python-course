number1 = int(input("Enter first number: "))
number2 = int(input("Enter second number: "))

if number1 * number2 < 1000:
    print("The product is:", number1 * number2)
else:
    print("The sum is:", number1 + number2)
