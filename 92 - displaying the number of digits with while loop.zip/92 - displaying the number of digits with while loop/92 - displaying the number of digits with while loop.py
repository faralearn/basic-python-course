x = int(input("Enter your number: "))
count = 0

while x != 0:
    x = x // 10
    count += 1

print("Your digits are:", count)
