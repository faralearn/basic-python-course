programmingGrade = int(input("Enter your programming grade: "))
mathGrade = int(input("Enter your math grade: "))
englishGrade = int(input("Enter your english grade: "))

ave = ((programmingGrade * 3) + (mathGrade * 2) + (englishGrade * 1)) / 6

print("Your average is:", ave)

if ave > 17:
    print("Top average")
else:
    print("Normal average")
