x = int(input("Enter start number: "))
y = int(input("Enter end number: "))

while x <= y:
    print("*" * x)
    x += 1
