x = int(input("Enter your number: "))

while x <= 100:
    if x % 2 == 0:
        print(x)
    x += 1
