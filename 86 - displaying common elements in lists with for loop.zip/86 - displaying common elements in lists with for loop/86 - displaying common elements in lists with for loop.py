list1 = [5, 8, 13, 8, 13, 9, 7, 3, 2]
list2 = [8, 2, 12, 19, 4, 26, 28, 1]

for i in list1:
    for j in list2:
        if i == j:
            print(i)




# for i in list1:
#     if i in list2:
#         print(i)
