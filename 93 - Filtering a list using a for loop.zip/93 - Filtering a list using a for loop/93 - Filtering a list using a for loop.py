# Define a list of numbers to filter
numbers = [12, 75, 150, 180, 145, 525, 50]

# Iterate through each item in the list 'numbers'
for item in numbers:
    # If the item is greater than 500, stop the loop
    if item > 500:
        break
    # If the item is greater than 150, skip to the next iteration
    if item > 150:
        continue
    # If the item is divisible by 5, print it
    if item % 5 == 0:
        print(item, end=" ")
