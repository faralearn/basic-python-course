x = input("Enter your string: ")

# Swap the first and last character
print(x[-1] + x[1:-1] + x[0])
