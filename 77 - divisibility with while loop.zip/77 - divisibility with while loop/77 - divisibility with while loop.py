x = int(input("Enter first number: "))
y = int(input("Enter second number: "))

while x < y:
    if x % 3 == 0 and x % 5 == 0:
        print(x)
    x += 1
