sum = 0
userNumber = 0
counter = 0

while userNumber != -1:
    sum += userNumber
    userNumber = int(input("Enter number: "))
    
    if userNumber != -1:
        counter += 1

print("Sum is:", sum)
print("Counter is:", counter)
print("Average is:", sum / counter)
