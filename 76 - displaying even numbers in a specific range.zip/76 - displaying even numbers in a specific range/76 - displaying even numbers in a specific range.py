x = int(input("Enter number for start loop: "))
y = int(input("Enter number for end loop: "))

while x <= y:
    if x % 2 == 0:
        print(x)
    x += 1
