x = input("Enter your string: ")

if len(x) > 3:
    print(x[-3:])  # Display last 3 characters
else:
    print(x)  # Display entire string if it's 3 characters or less
