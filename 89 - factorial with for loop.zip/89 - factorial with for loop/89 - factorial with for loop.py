n = int(input("Enter your number: "))
m = 1

for i in range(1, n + 1):
    m = m * i

print(m)
