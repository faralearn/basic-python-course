name = input("Enter your name: ")

if name.lower() == "ali":
    print("ok")
else:
    print("error")
