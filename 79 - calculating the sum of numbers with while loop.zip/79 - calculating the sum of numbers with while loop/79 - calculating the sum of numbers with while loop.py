x = int(input("Enter start number: "))
y = int(input("Enter end number: "))

sum = 0

while x <= y:
    sum = sum + x
    x += 1

print("Sum is:", sum)
