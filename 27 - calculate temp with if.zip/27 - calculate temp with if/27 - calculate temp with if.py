C = int(input("Enter your temperature (°C): "))
F = (C * (9/5)) + 32

if F > 90:
    print(F, "warning")
else:
    print(F, "cool")
