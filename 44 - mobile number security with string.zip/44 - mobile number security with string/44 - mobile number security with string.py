phoneNumber = input("Enter your phone number: ")

if len(phoneNumber) == 11 and phoneNumber.startswith("09"):
    print(phoneNumber.replace(phoneNumber[4:8], "****"))
else:
    print("error")
