x = int(input("Enter first number: "))
y = int(input("Enter second number: "))
z = int(input("Enter third number: "))

if z < x + y and y < x + z and x < y + z:
    print("مثلث داریم")

    if x == y and y == z:
        print("مثلث متساوی الاضلاع")
    elif x == y or y == z or x == z:
        print("مثلث متساوی الساقین")
    elif x != y and y != z and x != z:
        print("مثلث مختلف الاضلاع")
        if x**2 == y**2 + z**2 or y**2 == x**2 + z**2 or z**2 == x**2 + y**2:
            print("مثلث قائم الزاویه")
else:
    print("مثلث نداریم")
