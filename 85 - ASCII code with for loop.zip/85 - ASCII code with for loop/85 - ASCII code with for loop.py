list = [67, 72, 73, 84, 95, 86]

# روش با while
x = 0
while x < len(list):
    print(chr(list[x]))
    x += 1

# روش با for
for x in list:
    print(chr(x))
