list1 = ["a", "b", "c", ["d", "e", ["f", "g"], "k"], "l", "m", "n"]
sub_list = ["h", "i", "j"]

# Append sub_list to the nested list within list1
list1[3][2].append(sub_list)

print(list1)
