age = int(input("Enter your age: "))

if age >= 18:
    print("valid age")
else:
    print("invalid age")
