year = int(input("Enter your year: "))

age = 2024 - year

if age >= 18:
    print("valid age")
else:
    print("invalid age")

print("Your age is (year):", age, "Your age is (month):", age * 12)
