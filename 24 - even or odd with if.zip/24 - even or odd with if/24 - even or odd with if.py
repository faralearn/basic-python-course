number = int(input("Enter your number: "))

if number % 2 == 0:
    print(number, "is even")
else:
    print(number, "is odd")
