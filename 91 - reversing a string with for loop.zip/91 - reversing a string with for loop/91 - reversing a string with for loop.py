x = input("Enter your number: ")

for i in range(len(x) - 1, -1, -1):
    print(x[i], end="")
