x = input("Enter your string: ")

if len(x) > 3:
    if x[-3:] == "ing":
        x += "ly"
        print(x)
    else:
        x += "ing"
        print(x)
else:
    print("error")
